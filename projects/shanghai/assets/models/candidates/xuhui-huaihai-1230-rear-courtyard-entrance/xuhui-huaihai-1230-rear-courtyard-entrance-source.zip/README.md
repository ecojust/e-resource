# 光明邨后排淮海中路1230号院向立面

本包收录院门、登记所见的邻窗和四层叠阳台的原创模型、绘制材质、量测与构建程序；照片作者及使用范围见本栋来源说明。程序、独立绘制的几何和纹理采用 MIT 许可。四层叠台以2016年的可见外观为主，2013年公开资料中可见的三层另有参数化记录。两个摄影站的光轴、横滚和实际图片尺寸用于核对投影。

解压后需 Python 3、NumPy、Shapely 2.1、Pillow、trimesh。编码需 gltfpack 与Node.js，原生编辑工程需 Blender。两个实拍机位的投影保留图像中心、宽高及像素长宽比。

```sh
src=projects/shanghai/source/precise/xuhui-huaihai-1230-rear-courtyard-entrance/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/court_finishes.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 含全部源文件的SHA-256和长度。网页、模型、编辑工程及源码的本期固定地址由项目公开页面提供。
