# 董竹君旧居18号楼可复建源码

模型记录愚园路1294号的18号山墙、南向券廊和院侧室外楼梯。山墙题号照片和外阶局部照片分别配准，后者约束楼梯比例，楼梯在庭院中的位置仍有估计。十个摄影视角与检查视角存于 source/cameras.json。两站像点、留出误差与已知范围见 measurements 和本模型的说明。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely、Pillow 和 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/changning-yuyuan-1294-dong-zhujun-garden-residence/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带四组程序色纹和法线。
