# 大福里3号院门与露台

原照由Livelikerw于2016年2月6日拍摄。门牌上可读“3”和“延庆路二十九弄”，旁边的4号牌区分了下一座院门。大号数字3的临摹轮廓按CC BY-SA 4.0提供。原片与许可见https://commons.wikimedia.org/wiki/File:Dafu_Li_Shanghai.JPG 。本包保存带SHA-256的脚本、程序纹理、摄像机、测量记录及所需的共用模块，路径与制作仓库一致。

从解压目录运行以下命令。两档建模使用Python 3、NumPy、Shapely 2.1和Pillow。压缩、逐面核对和可编辑工程另需Node.js、gltfpack及Blender。下列各通用脚本的帮助可通过 --help 查看。

```sh
src=projects/shanghai/source/precise/xuhui-dafuli-yanqing-29-no3-court/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```
