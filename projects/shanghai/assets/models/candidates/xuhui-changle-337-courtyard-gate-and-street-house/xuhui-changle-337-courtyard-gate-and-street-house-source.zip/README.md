# 长乐坊337号院门与临街住宅

本包收录院门、临街窗墙、退进翼、照片可辨的瓦檐及高窗层，随附公制投影、闭体检查和模型自渲程序。模型和程序纹理按 CC BY-SA 4.0 发布。2017年 Antigng 照片及冬季街面影像的出处见本栋来源说明。复建所需图像为程序生成的纹理。

解压后需 Python 3、NumPy、Shapely 2.1、Pillow、SciPy、trimesh。编码需 gltfpack 与Node.js，原生编辑工程需 Blender。三个实拍机位的投影保留图像中心、宽高及像素长宽比。

```sh
src=projects/shanghai/source/precise/xuhui-changle-337-courtyard-gate-and-street-house/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/street_finishes.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 含全部源文件的SHA-256和长度。网页、模型、编辑工程及源码的本期固定地址由项目公开页面提供。
