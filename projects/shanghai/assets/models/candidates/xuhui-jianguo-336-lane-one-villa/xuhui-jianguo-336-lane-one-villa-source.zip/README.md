# 福德坊建国西路336弄1号住宅

本包重建院内住宅、前部两对圆柱、弧形下阳台、上层直廊、两翼切角窗和西侧窗墙。门阶、栏杆与窗下浮雕均保留独立几何。门内暖色玻璃灯保留独立发光材质。四个有证据的现场站位为02、03、04和05。编辑工程内的三台摄影对照相机保留03、04和05原位的透视与横滚；隔门看西墙的02站用于独立核验。点位、误差及照片较难辨认的部位见 measurements 目录。

在解压目录使用 Python 3、NumPy、Shapely 2.1 和 Pillow，运行以下命令。重算摄影相机需 SciPy。网页编码需 gltfpack 和 Node.js，编辑工程需 Blender。

```sh
src=projects/shanghai/source/precise/xuhui-jianguo-336-lane-one-villa/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/finish_surfaces.py" --output rebuilt/finishes
python "$src/roof_finish.py" --output rebuilt/roof-only
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 记录源码、原创纹理与测量文件，包括字节数及 SHA-256。院面照片由高参88的图集收录，各幅署名与可确认的拍摄时间见 measurements 内的记录。原摄影作品需由读者根据来源自取，包内附原创几何和程序纹理。
