# 五原路372弄6–9号栖霞村

这是上海市第五批优秀历史建筑 5D071 的三维模型源码。2016年1月20日连续拍摄的院面照片可辨认6、7、9号。中间一张通过相邻窗框和阳台与两侧配准，8号单户界线仍有不确定性。照片的原始网址、像点、相机参数、尺度假设和屋顶定位记录保存在 measurements 目录。图像作者为「中国の風景」，图集见 https://4travel.jp/travelogue/11103136 。

在解压目录运行以下命令，使用 Python 3、NumPy、Shapely 2.1 和 Pillow。重算联合摄影机另需 SciPy。压缩网页模型需要 gltfpack 和 Node.js，编辑工程需要 Blender。

```sh
src=projects/shanghai/source/precise/xuhui-qixia-village-wuyuan-372/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/court_finishes.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 记录包内源码、原创程序纹理和测量文件的字节数及 SHA-256。原摄影作品保存在所引网站。
