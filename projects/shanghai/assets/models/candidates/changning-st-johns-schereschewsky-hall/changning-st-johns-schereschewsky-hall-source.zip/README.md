# 怀施堂（韬奋楼）可复建源码
 
本包包括两面钟楼、街院券廊、南院铜像、横翼与北面两个小院。十处主楼机位中，三处使用已登记照片的相机投影。四种原创饰面的采样来源和条件尺度见本栋资料。
 
解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely、Pillow 和 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/changning-st-johns-schereschewsky-hall/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带四组程序色纹和法线。
