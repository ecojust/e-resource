# 新乐坊143-1号临街转角
    
程序几何、材质和九个分镜重建2018年有门牌的临街窗墙、进弄的窗墙与屋檐。砖与粗抹面颜色、法线均为原创程序纹理。数值取样、摄影站位及图片署名见项目说明和测量记录。建模照片为 Antigng 2018-02-07 作品，源图和各年街景由原站提供。本包内的几何和纹理依项目许可 CC BY-SA 4.0 发布。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely 和 Pillow；重新拟合机位另需 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/xuhui-xinle-143-1-street-corner/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender和FBX保留牌面白字的自发光。OBJ的MTL在Ke字段保存线性发光色。用Blender打开OBJ可运行包内import_wavefront.py，使无发光贴图的数值Ke也按强度1显示。
