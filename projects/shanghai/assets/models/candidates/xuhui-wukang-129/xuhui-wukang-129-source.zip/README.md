# 武康路129号住宅

建筑与原地块沿用本目录的原有城市对象，修订件保存在revision-3。两实照分别为Antigng（2017）和Windmemories（2026），均为 CC BY-SA 4.0；原作者、许可及坐标条件见LICENSES.md和两期摄影控制数据。自绘的涂面颜色、法线及门拱、开启窗几何均不嵌实拍照片。模型按 CC BY-SA 4.0 发布。OSM地块的ODbL-1.0许可与署名单列于原数据。

解压后需 Python 3、NumPy、Shapely 2.1、Pillow、trimesh。编码需 gltfpack 与Node.js，原生编辑工程需 Blender。两个实拍机位的投影保留图像中心、宽高及像素长宽比。

```sh
src=projects/shanghai/source/precise/xuhui-wukang-129/revision-3/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/finish_surfaces.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 含全部源文件的SHA-256和长度。网页、模型、编辑工程及源码的本期固定地址由项目公开页面提供。
