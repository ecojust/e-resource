# 新华村12号山墙、院廊可复建源码
 
模型包括数字12、三层绿色窗、粗砂与红砖山墙、花园侧的两层三跨凹廊和台基砖券。三台已登记照片的相机与七台检查相机保存于网页与可编辑工程。两期照片、院廊测量和两期底图的核对记录保存在 measurements 目录。
 
解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely、Pillow 和 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/changning-xinhuacun-12-numbered-gable/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带四组程序色纹和法线。
