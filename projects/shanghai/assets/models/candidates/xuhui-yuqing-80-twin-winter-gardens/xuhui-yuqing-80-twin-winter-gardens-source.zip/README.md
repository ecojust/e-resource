# 余庆路80号双圆冬园

上海市第五批优秀历史建筑名录将余庆路80号列作5D075住宅。此模型选取同址建筑中有两处圆形冬园的主楼朝花园立面。两张照片从东北、西南方向观察各段。像点、拟合、米制坐标、航片弧线依据以及局部遮挡误差保存在 measurements 目录。摄影署名与原作网址见 garden-photograph-sources.json。

在解压目录运行以下命令，使用 Python 3、NumPy、Shapely 2.1 和 Pillow。重算联合摄影机另需 SciPy。复现两张原摄影机位的自然采光渲染另需 C 编译器。压缩网页模型需要 gltfpack 和 Node.js，编辑工程需要 Blender。

```sh
src=projects/shanghai/source/precise/xuhui-yuqing-80-twin-winter-gardens/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/garden_finishes.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/../measurements/render_garden_daylight.py" rebuilt/whole/full-source.glb rebuilt/daylight --width 768
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 记录包内源码、原创程序纹理和测量文件的字节数及 SHA-256。原摄影作品保存在所引网站。
