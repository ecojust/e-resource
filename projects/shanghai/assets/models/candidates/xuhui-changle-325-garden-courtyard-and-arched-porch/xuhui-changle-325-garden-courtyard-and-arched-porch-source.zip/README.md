# 长乐路325号院内弧窗与红瓦券廊
    
本包还原Fayhoo于2015年4月4日拍摄的弧形窗墙、十级石阶、红瓦券廊、栏杆及玻璃门。照片见作品页，几何、程序色纹和法线按CC BY-SA 3.0共享。第二个街侧摄影站的坐标和误差见measurements。院内遮挡和瓦口实测的适用范围见各构件说明。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely 和 Pillow；重新拟合机位另需 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/xuhui-changle-325-garden-courtyard-and-arched-porch/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带三组程序色纹和法线。
