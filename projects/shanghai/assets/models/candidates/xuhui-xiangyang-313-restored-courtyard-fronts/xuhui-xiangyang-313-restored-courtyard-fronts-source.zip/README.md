# 襄阳南路313号修缮后院面

本包保存两处院面的程序几何、材料、九镜相机、市图平面和公开照片的像素读数。模型与程序生成纹理依本栋授权说明采用 MIT。施工方网页的照片由原权利人持有；包中收录其署名、链接和人工量取的点位。复建无需下载施工方照片。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely 和 Pillow；重新拟合机位另需 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/xuhui-xiangyang-313-restored-courtyard-fronts/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX包含建筑网格，OBJ下载包包括OBJ、MTL及用到的程序纹理。STL以米为坐标单位。
