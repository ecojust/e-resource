# 新华路329弄36号圆形住宅庭院立面
       
工程包含历史照片和2024年照片记录的院门、双层弧廊、窗面及瓦檐。玻璃门窗和格子玻璃分别保留两种透光度。摄影来源、取景范围与推定尺寸见本栋说明和测量记录。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely 和 Pillow；重新拟合机位另需 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/changning-xinhua-329-no36-cake-villa/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带两组程序色纹和法线。
