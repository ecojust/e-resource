# 陕西南路222弄20号住宅院门

门柱、门扇、兽面拉环及檐部的三段卵饰依据高参88发布的两幅实照制作。照片出处为 https://blog.sina.com.cn/s/blog_5d1bdf480102whoy.html 。模型采用假设的门牌尺寸和门环高度换算米制比例，手工核像和深度灵敏度记录见 measurements。本包保存带SHA-256的脚本、程序纹理、摄像机、测量记录及所需的共用模块，路径与制作仓库一致。

从解压目录运行以下命令。两档建模使用Python 3、NumPy、Shapely 2.1和Pillow。复核照片控制点另需SciPy，照片取景渲染另需C编译器。压缩、逐面核对和可编辑工程另需Node.js、gltfpack及Blender。下列各通用脚本的帮助可通过 --help 查看。

```sh
src=projects/shanghai/source/precise/xuhui-shaanxi-222-no20-residence-gate/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```
