# 新华路梅泉别墅弄口
       
工程重建路口的题名石牌、浅色砖门柱、压顶、乳白灯罩和铁门。侧视与正面摄影机可对照各部分的实际位置。浅色砖和题名石牌分别使用程序生成的颜色与切线空间法线。摄影来源与推定范围见本栋说明及测量记录。

解压后，从本目录运行下列命令。建模使用 Python 3、NumPy、Shapely 和 Pillow；重新拟合机位另需 SciPy，GLB 编码需 Node.js 和 gltfpack，原生与交换格式需 Blender 4.3 或较新版本。

```sh
src=projects/shanghai/source/precise/changning-meiquan-villas-inscribed-entrance/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
python "$src/package_exchange.py" rebuilt/packaged rebuilt/exchange
```

source-files.json列出源件字节数及SHA-256。FBX为带材质的建筑网格，OBJ包包含几何、材质库和程序纹理。STL仅承载几何形状，坐标单位为米。GLB、Blender、FBX及OBJ附带两组程序色纹和法线。
