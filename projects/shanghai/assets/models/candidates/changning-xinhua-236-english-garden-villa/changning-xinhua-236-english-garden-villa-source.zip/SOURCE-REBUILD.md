解包后，在有项目 Python 建模依赖的环境中运行 python rebuild.py output。两级 GLB 的校验值在下载验证记录中。
