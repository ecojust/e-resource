from pathlib import Path
import subprocess,sys
entry=Path(__file__).resolve().parent/'source/precise/changning-xinhua-236-english-garden-villa/source/build_model.py'
out=Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=True)
for role,extra in [('full',[]),('lod',['--lod'])]:
    subprocess.run([sys.executable,'-B',entry,*extra,'--output',out/(role+'-source.glb')],check=True)
