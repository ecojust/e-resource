# 延庆路2号浅绿住宅

2015年6月21日，Fayhoo拍摄了沿街的延庆路2号，照片可见同一面墙上的两块2号门牌。原照采用 CC BY-SA 3.0 许可，见 https://commons.wikimedia.org/wiki/File:Yanqinglu_2_Hao_Zhuzhai.JPG 。同年冬季的多个站位用于校正弧形楼梯井、凸窗、阳台、端墙和檐线。程序纹面等资源按实际建模清单保存在 source 目录。本包保存带SHA-256的脚本、程序纹理、摄像机、测量记录及所需的共用模块，路径与制作仓库一致。

从解压目录运行以下命令。两档建模使用Python 3、NumPy、Shapely 2.1和Pillow。复核照片控制点另需SciPy，照片取景渲染另需C编译器。压缩、逐面核对和可编辑工程另需Node.js、gltfpack及Blender。下列各通用脚本的帮助可通过 --help 查看。

```sh
src=projects/shanghai/source/precise/xuhui-yanqing-2-green-street-residence/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```
