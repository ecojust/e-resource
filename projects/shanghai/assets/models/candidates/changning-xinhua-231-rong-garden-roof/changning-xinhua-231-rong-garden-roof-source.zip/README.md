# 新华路231号住宅花园侧模型源码

在解压目录运行 `python rebuild.py output`，即可生成近远两个 GLB、构件表、照片配准及首击结果、彩瓦纹理对照图。生成时使用包内的共用几何工具。依赖版本列于 requirements.txt。从 source/precise/changning-xinhua-231-rong-garden-roof/source/ 进入本栋模型的部件、材质和机位定义，照片来源和量取值在同栋的 measurements/。相机对齐沿用宽550像素的公开图，外部摄影与航片由各自来源提供。
