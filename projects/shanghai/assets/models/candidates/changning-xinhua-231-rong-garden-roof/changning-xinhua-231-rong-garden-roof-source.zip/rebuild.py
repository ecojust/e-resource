from pathlib import Path
import argparse
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('output', type=Path)
out = p.parse_args().output.resolve()
out.mkdir(parents=True, exist_ok=True)
building = root/'source/precise/changning-xinhua-231-rong-garden-roof'
env = dict(os.environ, OPENBLAS_NUM_THREADS='1',
           OMP_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
env.pop('E_RESOURCE_SHANGHAI', None)
def run(script, *args):
    subprocess.run([sys.executable, '-B', building/script, *args], check=True, env=env)
run('source/build_model.py', '--output', out/'full-source.glb')
run('source/build_model.py', '--lod', '--output', out/'lod-source.glb')
run('measurements/check_actual_meshes.py', out, out/'mesh-and-photo-check.json')
run('measurements/roof_views.py', out)
