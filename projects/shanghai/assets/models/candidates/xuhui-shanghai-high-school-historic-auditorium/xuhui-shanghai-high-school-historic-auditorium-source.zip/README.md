# 上海中学历史大礼堂

建筑外观依据1934年由Guangchan转引国家图书馆的老照片，以及“大器”校友图文内自带2020年10月17日水印的正门照片。入口、门上几何饰和石阶取2020年。高墙、东翼开间和屋顶结合1934年资料、公开影像及现有屋面量读，尺度与遮挡处的限制见 measurements。照片链接及署名保存在相应的测量记录，源包内的几何和颜色、法线图为项目原创。

解压后用 Python 3、NumPy、Shapely 2.1、Pillow 及 trimesh 运行下列命令。重算摄影参数需 SciPy，软件光栅绘图需 C 编译器。编码需 gltfpack 和 Node.js，原生编辑工程需 Blender。两台历史照片对照相机按固定测量矩阵建成，另有七个建筑观察机位。

```sh
src=projects/shanghai/source/precise/xuhui-shanghai-high-school-historic-auditorium/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/finish_surfaces.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 含全部源文件的SHA-256和长度。网页、模型、编辑工程及源码的本期固定地址由项目公开页面提供。
