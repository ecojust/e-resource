# 陕西南路202号怡和医院旧址庭院立面

此包包含庭院砖石立面、两处镂空阳台、拱形门廊、吊灯、木门、两件石狮、西侧翼与屋顶的可编辑源。四处照片参考和投影误差见 measurements 目录。门廊右狮爪下能辨绣球，左狮爪下形象受遮挡。庭内台基深度为摄影估算。

在解压目录使用 Python 3、NumPy、Shapely 2.1 和 Pillow，运行以下命令。重算摄影相机需 SciPy。网页编码需 gltfpack 和 Node.js，编辑工程需 Blender。

```sh
src=projects/shanghai/source/precise/xuhui-shaanxi-202-former-yihe-hospital/source
mkdir -p rebuilt/whole rebuilt/packaged rebuilt/native
python "$src/finish_surfaces.py" --output rebuilt/finishes
python "$src/build_model.py" --output rebuilt/whole/full-source.glb
python "$src/build_model.py" --output rebuilt/whole/lod-source.glb --lod
python "$src/package_model.py" rebuilt/whole rebuilt/packaged --gltfpack gltfpack
python "$src/package_editable.py" prepare rebuilt/packaged rebuilt/native
python "$src/package_editable.py" run rebuilt/packaged rebuilt/native
```

source-files.json 记录源码、原创纹理与测量文件，包括字节数及 SHA-256。摄影作品由署名来源提供。
