"""Start this site's prepared map once, after the previous reviewer has signed the physical exit."""
from pathlib import Path
import fcntl,json,os,subprocess,sys,time
q=Path(__file__).resolve().parent
job=int(q.name[-3:])
source={204:Path('/tmp/brookside203/203-map-slot-released.json'),208:Path('/tmp/haig207/207-city/207-map-slot-released.json')}[job]
with (q/'actual-map.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 while not source.is_file():time.sleep(3)
 previous=json.loads(source.read_bytes());assert previous['order']==job-1 and previous['passed']
 if job==204:
  assert previous['exit_code']==0 and not previous['remaining_chromium'] and previous['all_captures_visually_reviewed']
 else:assert previous['final_closed_at']
 if not (q/'all-main-outcomes.json').is_file():
  with (q/'formal.log').open('ab',buffering=0)as log:subprocess.run([sys.executable,'-Bu',q/'run-main.py'],check=True,stdout=log,stderr=log)
