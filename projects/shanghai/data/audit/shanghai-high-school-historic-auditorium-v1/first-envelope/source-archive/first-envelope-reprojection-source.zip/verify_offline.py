"""Rebuild the first two mesh levels, the two cameras, their ray checks, and their rendered views."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / 'projects/shanghai/source/precise/xuhui-shanghai-high-school-historic-auditorium'
MEASURE = MODEL / 'measurements'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main(out):
    out.mkdir(parents=True, exist_ok=True)
    for name, expected in json.loads((ROOT / 'contents.json').read_text()).items():
        if digest(ROOT / name) != expected:
            raise ValueError('Unexpected archived member ' + name)
    def run(script, *args):
        subprocess.run([sys.executable, str(script), *map(str, args)], check=True,
                       env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, cwd=out)
    output = {}
    def verify(actual, target):
        if digest(actual) != digest(target):
            raise ValueError('Reproduction differs: ' + actual.name)
        output[actual.name] = digest(actual)
    run(MEASURE / 'fit_registered_cameras.py', out / 'court-cameras.json')
    verify(out / 'court-cameras.json', MEASURE / 'court-cameras.json')
    for kind, evidence in [('full', 'first-mesh-photo-rays.json'), ('lod', 'first-lod-photo-rays.json')]:
        mesh = out / (kind + '-source.glb')
        extra = ['--lod'] if kind == 'lod' else []
        run(MODEL / 'source/build_model.py', '--output', mesh, *extra)
        verify(mesh, ROOT / 'first-mesh' / mesh.name)
        run(MEASURE / 'check_registered_hall.py', mesh, out / evidence)
        verify(out / evidence, ROOT / 'results' / evidence)
    run(MEASURE / 'render_registered_hall.py', out / 'full-source.glb', out / 'render', '--width', 840)
    for name in ['view-1934.jpg', 'view-2020.jpg', 'registered-hall.jpg', 'registered-renders.json']:
        verify(out / 'render' / name, ROOT / 'results' / name)
    return {'members_checked': len(json.loads((ROOT / 'contents.json').read_text())),
            'rebuilt': output}


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('output', type=Path)
    args = cli.parse_args()
    print(json.dumps(main(args.output), indent=2))
