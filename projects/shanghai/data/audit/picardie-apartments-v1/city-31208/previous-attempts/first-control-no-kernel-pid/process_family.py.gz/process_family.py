"""Observe Chromium descendants by kernel process lineage, including a browser without an explicit profile argument."""
from pathlib import Path

def chrome_descendants(root_pid):
    pending=[int(root_pid)]
    result={}
    visited=set()
    while pending:
        pid=pending.pop()
        if pid in visited:continue
        visited.add(pid)
        proc=Path('/proc')/str(pid)
        try:
            stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
            if stat[0] in ('X','Z'):continue
            if (proc/'comm').read_text().strip() in ('chromium','chrome'):
                result[pid]=int(stat[19])
            for children in (proc/'task').glob('*/children'):
                pending.extend(int(p)for p in children.read_bytes().split())
        except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    return result

def still_alive(observed):
    result=[]
    for pid,start in observed.items():
        try:stat=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split()
        except (FileNotFoundError,ProcessLookupError):continue
        if int(stat[19])==start and stat[0] not in ('X','Z'):result.append(pid)
    return result
