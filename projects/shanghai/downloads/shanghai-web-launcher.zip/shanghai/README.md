# 上海漫游 v4 启动包

上海漫游 v4 · 本地网页启动包

一、启动
完整解压后进入 shanghai 目录，在该目录运行：
    python -m http.server 8000
macOS/Linux 如使用 python3：
    python3 -m http.server 8000
浏览器打开 http://localhost:8000 。不要用 file:// 直接双击 index.html。

二、包内与联网部分
本包包含网页程序、本地第三方库、14个网页优化地标、外滩街道模型、
10个外滩建筑远景LOD、9张本地1K表面纹理、外滩参考照片及运行时数据。
原始GLB、Blender源文件和全市分块没有打入本包。
漫游仍需联网：道路、水系、中文标注和远景地图来自公开地图服务；
全市 1,708 个建筑分块及精确ID索引按需从固定Git提交加载。
固定提交：863c315bccf80acada4ef1f8477ad488c85a2b6f
这不是完整离线城市地图；断网时地图服务和未缓存的全市分块不可用。

三、操作
WASD/方向键行走，Shift加速，拖动转向，滚轮调镜头；Q/E转动，R重置。
手机使用摇杆。俯瞰模式双击地图可选起点；建筑“参考照片”可查看来源与署名。

四、模型与精度
外滩建筑按公开照片和轮廓复建柱廊、凹窗、檐口及屋顶；未获得实测资料的
尺寸与侧后细节含推定。近处使用完整建筑、远处切换精简LOD；表面纹理来自
可再分发的通用石材与沥青素材，不代表对外滩实地材料的扫描。全市普通建筑
仍是公开足迹挤出的体块背景，高度以
公开预测/栅格估计为主。两类模型均不能用作测绘或现实导航。

完整项目、原始模型、Blender文件、重建源码及来源：
https://github.com/ecojust/e-resource/tree/863c315bccf80acada4ef1f8477ad488c85a2b6f/projects/shanghai

代码许可见 LICENSE，第三方库许可见 licenses/；照片作者、许可和原网页
保留在 data/landmarks.json，界面参考图弹窗同时显示署名。照片许可不被代码MIT替代。
表面纹理为CC0；作者、来源、原始文件校验值及许可全文保留在
assets/materials/realism-v4/；不需要联网下载这些纹理。
更多数据说明见 data/SOURCES.md、data/heights/HEIGHT_SOURCES.md 和 data/bund/。
